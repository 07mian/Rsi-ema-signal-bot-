# Rsi-ema-signal-bot-
A telegram bot that send me rsi + ema signals
